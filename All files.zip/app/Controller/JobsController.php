<?php

class JobsController extends AppController{
    public $name="Jobs";
    
    //Index Page
    public function index() {
        //Set Query Options
           $options=array(
            'order'=>array('Category.name'=>'asc')
            
        );        
        $categories= $this->Job->Category->find('all',$options);
        $this->set('categories',$categories); 

        $options=array(
            'order'=>array('Job.created'=>'desc'),
            'limit'=>10
        );
        //Get Job Info
        $jobs= $this->Job->find('all',$options);
        
         $this->set('title_for_layout', 'Job Finds | Welcome ');
        $this->set('jobs',$jobs); 
        
        
       
    }
    //Browse Jobs
    public function browse($category=null){
        $conditions=array();
        //Keyword Filter
        if($this->request->is('post')){
            
            if (!empty($this->request->data('keywords'))){
                
                  $conditions[]=array(
                      'OR'=>array(
                'Job.title LIKE'=>"%".$this->request->data('keywords')."%",
                      'Job.description LIKE'=>"%".$this->request->data('keywords')."%"
            )); 
            }
        }
        //District Filter
         if (!empty($this->request->data('district')) && $this->request->data('district') !='Select District' ){
            $conditions[]=array(
                'Job.district LIKE'=>"%".$this->request->data('district')."%"
            ); 
         }
         
         //Category Filter
         if (!empty($this->request->data('category')) && $this->request->data('category') !='Select Category' ){
            $conditions[]=array(
                'Job.category_id LIKE'=>"%".$this->request->data('category')."%"
            ); 
         }
        
        $options=array(
            'order'=>array('Category.name'=>'asc')
            
        );
        
        $categories= $this->Job->Category->find('all',$options);
        
        $this->set('categories',$categories); 
        
        
       
        
        if ($category !=null){
            $conditions[]=array(
                'Job.category_id LIKE'=>"%".$category."%"
            );
        }
        $options=array(
            'order'=>array('Job.created'=>'desc'),
            'conditions'=> $conditions,
            'limit'=>10
         );
        
         $jobs= $this->Job->find('all',$options);
         
         $this->set('title_for_layout', 'Job Finds | Browse Jobs ');
         
          $this->set('jobs',$jobs); 
    } 
          public function view($id){
              if (!$id){
                 throw new NotFoundException(__('Invalid Job Listing')); 
              }
              
              $job= $this->Job->findById($id);
              
                  if (!$job){
                 throw new NotFoundException(__('Invalid Job Listing')); 
              }
             
              $this->set('title_for_layout', $job ['Job']['title']);
              
              $this->set('job',$job); 
          }
            //Add Job
          public function add(){
                $options=array(
            'order'=>array('Category.name'=>'asc')
            
        );  
                
                $categories= $this->Job->Category->find('list',$options);
                
                  $this->set('categories',$categories); 
              
                  
            $types= $this->Job->Type->find('list');  
             $this->set('types',$types); 
              if($this->request->is('post')){
                  $this->Job->create(); 
                  
                  $this->request->data['Job']['user_id']= $this->Auth->user('id');
                  
                  if( $this->Job->save( $this->request->data)){
                      $this->Session->setFlash(__('Your Job has been listed'));
                      return $this->redirect(array(
                          'action'=>'index'
                      ));
                  }
                   $this->Session->setFlash(__('Unable to add your job'));
             }  
          }
          
          /*
           * Edit Job
           */
           public function edit($id){
                $options=array(
            'order'=>array('Category.name'=>'asc')
            
        );  
                
                $categories= $this->Job->Category->find('list',$options);
                
                  $this->set('categories',$categories); 
              
                  
            $types= $this->Job->Type->find('list');  
             $this->set('types',$types); 
             
                if (!$id){
                 throw new NotFoundException(__('Invalid Job Listing')); 
              }
              
              $job= $this->Job->findById($id);
              
                  if (!$job){
                 throw new NotFoundException(__('Invalid Job Listing')); 
              }
             
              if($this->request->is(array('job','put'))){
                  $this->Job->id=$id; 
                  
                  
                  
                  if( $this->Job->save( $this->request->data)){
                      $this->Session->setFlash(__('Your Job has been updated'));
                      return $this->redirect(array(
                          'action'=>'index'
                      ));
                  }
                   $this->Session->setFlash(__('Unable to update your job'));
             }
             if(!$this->request->data){
                 $this->request->data=$job;
             }
          }
          
          public function delete($id){
              if ($this->request->is('get')){
                  throw new MethodNotAllowedException();
              }
              if($this->Job->delete($id)){
                  $this->Session->setFlash(
                          __('The Job with id: %s has been deleted.',h($id))
                          );
                          return $this->redirect (array ('action'=>'index'));
              }
          }
    }

