<?php
App::uses ('AppModel','Model');
App::uses('SimplePasswordHasher','Controller/Component/Auth');
class User extends AppModel {
    public $name='User';
    
    public function beforeSave($options=array()){
        if(isset($this->data[$this->alias]['password'])){
            $passwordHasher=new SimplePasswordHasher();
            $this->data[$this->alias]['password']=$passwordHasher->hash(
                    $this->data[$this->alias]['password']
                    );
        }
        return true;
    }
    public $validate = array(
        'first_name' => array(
            'alphaNumeric' => array(
                'rule' => 'alphaNumeric',
                'required' => true,
                'message' => 'Letters and Numbers Only'
            ),
            'notBlank' => array(
                'rule' => 'notBlank',
                'message' => 'Please Enter Your First Name'
            )
        ),
        'last_name' => array(
            'alphaNumeric' => array(
                'rule' => 'alphaNumeric',
                'required' => true,
                'message' => 'Letters and Numbers Only'
            ),
            'notBlank' => array(
                'rule' => 'notBlank',
                'message' => 'Please Enter Your last Name'
            )
        ),
        'email' => array(
            'email' => array(
                'rule' => 'email',
                'required' => true,
                'message' => 'Please Enter an Email Address'
            ),
            'notBlank' => array(
                'rule' => 'notBlank',
                'message' => 'Please Enter an Email Address'
            )
        ),
        'password' => array(
            'notBlank' => array(
                'rule' => 'notBlank',
                'message' => 'Please Enter Your Password'
            )
        ),
        'confirm_password' => array(
            'notBlank' => array(
                'rule' =>  'notBlank',
                'message' => 'Please Enter Your Password'
           
        ),
        'matchPasswords' => array(
            
                'rule' =>  array('identicalFieldValues','password'),
                'message' => 'Your Passwords do not match'
            )
        )
    );
    
    function identicalFieldValues($field=array(), $compare_field=null){
        foreach ($field as $key => $value) {
            $v1=$value;
            $v2= $this->data[$this->name][ $compare_field ];
            if ($v1 !=$v2){
                return FALSE;
            }else{
                continue;
            }
        }
        return TRUE;
    }
   

}
