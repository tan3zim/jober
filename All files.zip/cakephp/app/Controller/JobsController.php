<?php

class JobsController extends AppController{
    public $name="Jobs";
    
    
    public function index() {
        //Set Query Options
        $options=array(
            'order'=>array('Job.created'=>'desc'),
            'limit'=>10
        );
        //Get Job Info
        $jobs= $this->Job->find('all',$options);
        $this->set('jobs',$jobs); 
    }
    
    public function browse($category=null){
        
         $conditions=array();
        
        if ($category !=null){
            $conditions=array(
                'Job.category_id LIKE'=>"%".$category."%"
            );
        }
        $options=array(
            'order'=>array('Job.created'=>'desc'),
            'conditions'=> $conditions,
            'limit'=>10
         );
        
         $jobs= $this->Job->find('all',$options);
         
          $this->set('jobs',$jobs); 
    }
}
